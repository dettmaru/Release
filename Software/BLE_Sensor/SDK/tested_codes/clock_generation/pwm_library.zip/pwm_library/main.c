#include <stdbool.h>
#include <stdint.h>
#include "nrf.h"
#include "app_error.h"
#include "bsp.h"
#include "nrf_delay.h"
#include "app_pwm.h"

APP_PWM_INSTANCE(PWM1,1);                   // Create the instance "PWM1" using TIMER1.

#define SMClock         NRF_GPIO_PIN_MAP(0,20)
#define SMClock_Read    NRF_GPIO_PIN_MAP(0,15) 
#define SMData          NRF_GPIO_PIN_MAP(0,2)
#define RLED            NRF_GPIO_PIN_MAP(1,0)
#define Adress          0x9c
#define Read            1
#define Write           0
#define Remote_1        0x01
#define Remote_2        0x02
#define Remote_3        0x03
#define Remote_4        0x04
#define Remote_5        0x05
#define Remote_6        0x06
#define Local           0x07
#define Remote_7        0x08


static volatile bool ready_flag;            // A flag indicating PWM status.



// PWM Callback Funktion
void pwm_ready_callback(uint32_t pwm_id)    // PWM callback function
{
    ready_flag = true;
}



// Initialisierung der PWM Funktion
void init_pwm(){
    ret_code_t err_code;
    /* 1-channel PWM, 10kHz, output on SMClock pins. */
    app_pwm_config_t pwm1_cfg = APP_PWM_DEFAULT_CONFIG_1CH(100, SMClock);

    /* Initialize and enable PWM. */
    err_code = app_pwm_init(&PWM1,&pwm1_cfg,pwm_ready_callback);
    APP_ERROR_CHECK(err_code);
}




// Initialisation of GPIO Pins
void init_gpio(){
    nrf_gpio_cfg_output(RLED);
    nrf_gpio_cfg_input(SMClock_Read, GPIO_PIN_CNF_PULL_Disabled);
    nrf_gpio_cfg_input(SMData, GPIO_PIN_CNF_PULL_Disabled);
}


// Read Clock State
bool get_clock_state(){
  return nrf_gpio_pin_read(SMClock_Read);
}


// Start SM Bus Clock with PWM
void stop_SMBus_clock(){
    app_pwm_disable(&PWM1);
}


// Stop SM Bus Clock with PWM
void start_SMBus_clock(){
    app_pwm_enable(&PWM1);
    // Set duty cycle 50%
    app_pwm_channel_duty_set(&PWM1, 0, 50); 
}



void set_SMData_pin_read_mode(){
    nrf_gpio_cfg_input(SMData, GPIO_PIN_CNF_PULL_Disabled);
}

void set_SMData_pin_write_mode(){
    nrf_gpio_cfg_output(SMData);
}







void write_start_condition(){

  // Set SMData to Output Mode and high level
  nrf_gpio_pin_set(SMData);
  set_SMData_pin_write_mode();

  // Start Clock
  start_SMBus_clock();
  nrf_delay_us(1);

  // Wait for high level (10%) to set start condition
  while(get_clock_state() == 0){};
  nrf_delay_us(1);

  // Set Startcondition, level change
  // during clock high level
  nrf_gpio_pin_clear(SMData);
}




void write_adress(void){

uint8_t i = 0;


    //Wait
    nrf_delay_us(3);

    if(Adress & (1 << 7)){
      nrf_gpio_pin_set(SMData);
    } else {
      nrf_gpio_pin_clear(SMData);        
    }
    //Wait
    nrf_delay_us(5);


  // Write 7 Bits of Slave Adress
  for(i = 6; i > 0; i--){

    // Wait for clock low level to change
    // data bit level 
    while(get_clock_state() == 1){};

    if(Adress & (1 << i)){
      nrf_gpio_pin_set(SMData);
    } else {
      nrf_gpio_pin_clear(SMData);        
    }

    //Wait
    nrf_delay_us(5);

  }

}


void write_mode(bool RW){

  // Wait for clock low level to change
  // data bit level 
  while(get_clock_state() == 1){};

  if(RW == 1){
    nrf_gpio_pin_set(SMData);
  } else {
    nrf_gpio_pin_clear(SMData);        
  }
}


bool read_ack(){

  // Set SM_Data to read mode
  set_SMData_pin_read_mode();

  // Wait for Acknowledge from slave
  for(uint8_t n = 10; n>0;n++){
    // Check for ack
    if(nrf_gpio_pin_read(SMData) == 1){
      // Ack received
      nrf_gpio_pin_set(RLED);
      return 1;
    }
    nrf_delay_us(1);
  }
  // Nock Acknowledge received
  return 0;
}




int main(void)
{
  uint32_t count = 0;
  init_pwm();
  init_gpio();

  write_start_condition();

  write_adress();

  write_mode(Write);

  read_ack();

  nrf_delay_us(10);

  stop_SMBus_clock();




    while (true)
    {
    }

}


/** @} */
